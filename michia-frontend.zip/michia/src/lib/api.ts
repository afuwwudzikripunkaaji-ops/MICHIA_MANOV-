const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
const KEY = "michia-token";

export const getToken = () => (typeof window === "undefined" ? null : localStorage.getItem(KEY));
export const setToken = (t: string | null) => (t ? localStorage.setItem(KEY, t) : localStorage.removeItem(KEY));

export class ApiError extends Error {
  constructor(public status: number, msg: string) { super(msg); }
}

type Opts = { method?: string; json?: unknown; form?: Record<string, string> };

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function api<T = any>(path: string, o: Opts = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let body: BodyInit | undefined;
  if (o.json !== undefined) { headers["Content-Type"] = "application/json"; body = JSON.stringify(o.json); }
  if (o.form) body = new URLSearchParams(o.form);

  let r: Response;
  try { r = await fetch(BASE + path, { method: o.method ?? "GET", headers, body }); }
  catch { throw new ApiError(0, "Tidak bisa terhubung ke server. Pastikan backend sedang berjalan."); }

  if (r.status === 204) return undefined as T;
  const d = await r.json().catch(() => null);
  if (!r.ok) {
    const msg = typeof d?.detail === "string" ? d.detail : r.status === 422 ? "Input tidak valid" : "Terjadi kesalahan";
    throw new ApiError(r.status, msg);
  }
  return d as T;
}
