// Simulasi berbasis kata kunci. TODO: ganti dengan panggilan ke backend FastAPI + LLM.
export type Det = { a: string; g: string; c: number; w: string };

export function detect(text: string): Det[] {
  const t = text.toLowerCase(), r: Det[] = [];
  if (/esp32|sensor|i2c|arduino|mikro|relay|rangkaian/.test(t))
    r.push({ a: "Belajar / troubleshooting embedded", g: "Menguasai Embedded System", c: 94, w: "Berkaitan langsung dengan milestone I2C & sensor pada goal Embedded System." });
  if (/coding|python|program|api|git/.test(t))
    r.push({ a: "Belajar programming", g: "Lebih mahir programming", c: 88, w: "Kata kunci coding/Python cocok dengan goal programming." });
  if (/nongkrong|teman|main/.test(t))
    r.push({ a: "Bersosialisasi", g: "Belum terhubung ke goal", c: 61, w: "Aktivitas sosial, belum jelas hubungannya dengan goal mana pun." });
  if (!r.length)
    r.push({ a: "Aktivitas umum", g: "Belum terhubung ke goal", c: 45, w: "AI belum cukup yakin. Kamu bisa menghubungkannya manual." });
  return r;
}

export const CONTEXTS = ["😊 Mood", "😴 Tidur & kesehatan", "💰 Keuangan", "👥 Sosial", "💼 Karier", "🎓 Kuliah"];
const RX: [string, RegExp][] = [
  [CONTEXTS[0], /kesal|senang|sedih|stres|stress|semangat|bahagia|cemas|bete/g],
  [CONTEXTS[1], /tidur|ngantuk|lelah|capek|sakit|begadang/g],
  [CONTEXTS[2], /uang|hemat|bokek|duit|nabung|bayar/g],
  [CONTEXTS[3], /teman|nongkrong|keluarga|organisasi|ngobrol/g],
  [CONTEXTS[4], /magang|karier|lowongan|cv|wawancara/g],
  [CONTEXTS[5], /kuliah|praktikum|tugas|dosen|ujian|laporan/g],
];

export function detectCtx(text: string) {
  const t = text.toLowerCase();
  return RX.flatMap(([n, re]) => {
    const m = t.match(re);
    return m ? [{ n, c: Math.min(92, 70 + m.length * 8), w: `Kata kunci “${m[0]}” muncul di jurnalmu.` }] : [];
  });
}
