// Warna asli ada di globals.css ([data-theme=...]); ini hanya untuk preview di picker.
export const THEMES = [
  { id: "rose", n: "Rose", c: ["#FFF5F5", "#F7D6D0", "#E2B4BD", "#4A4A4A"] },
  { id: "ocean", n: "Ocean", c: ["#3368A0", "#66A3BF", "#C8DFDB", "#F2EFE7"] },
  { id: "lime", n: "Lime Sun", c: ["#FDD04E", "#FFF14A", "#B3DA5B", "#7DC24F"] },
  { id: "sky", n: "Sky Sand", c: ["#F9E8A2", "#B4E1EB", "#95BDD7", "#78A4CB"] },
  { id: "burgundy", n: "Burgundy", c: ["#800020", "#F2E4D5", "#FFF8F2", "#D65262"] },
];
