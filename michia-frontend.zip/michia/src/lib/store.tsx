"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */
import { createContext, useContext, useEffect, useRef, useState, ReactNode } from "react";
import { api, getToken, setToken } from "./api";
import { CONTEXTS } from "./detect";
import { AIMode, Goal, Habit, Journal, Priority, State, initial } from "./types";

const CTX_ENUM = ["mood", "sleep_health", "finance", "social", "career", "study"]; // urutan sama dengan CONTEXTS
const today = () => new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD zona waktu lokal user
const cap = (p: string) => (p[0].toUpperCase() + p.slice(1)) as Priority;

const mapGoal = (g: any): Goal => ({ id: g.id, n: g.name, why: g.why ?? "(belum diisi)", p: cap(g.priority),
  ms: g.milestones.map((m: any) => ({ id: m.id, t: m.title, d: m.done })) });
const mapHabit = (h: any): Habit => ({ id: h.id, n: h.name, d: h.done_today, tpw: h.target_per_week, wk: h.done_this_week });
const mapJournal = (j: any): Journal => ({ id: j.id, t: j.body, ts: Date.parse(j.created_at),
  x: j.contexts.map((c: any) => CONTEXTS[CTX_ENUM.indexOf(c.context)]) });

type GoalIn = { n: string; w: string; p: Priority; lines: string[] };
type ProfilePatch = { name?: string; theme?: string; aiMode?: AIMode; done?: boolean };

export type Actions = {
  toggleHabit: (id: string, done: boolean) => Promise<void>;
  addHabit: (name: string, perWeek: number) => Promise<void>;
  delHabit: (id: string) => Promise<void>;
  addJournal: (text: string, ctx: string[]) => Promise<void>;
  setJournalCtx: (id: string, ctx: string[]) => Promise<void>;
  delJournal: (id: string) => Promise<void>;
  addGoal: (g: GoalIn) => Promise<void>;
  saveGoal: (id: string, g: GoalIn) => Promise<void>;
  delGoal: (id: string) => Promise<void>;
  toggleMs: (goalId: string, msId: string, done: boolean) => Promise<void>;
  updateProfile: (p: ProfilePatch) => Promise<void>;
  deleteAccount: () => Promise<void>;
};

type Ctx = {
  s: State; ready: boolean; authed: boolean;
  set: (f: (s: State) => State) => void; // khusus data lokal (activities, reflections)
  act: Actions;
  login: (email: string, pw: string) => Promise<void>;
  register: (email: string, pw: string, name: string) => Promise<void>;
  logout: () => void;
};
const C = createContext<Ctx | null>(null);

export function Provider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<State>(initial);
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  const userId = useRef("");
  const patch = (p: Partial<State>) => setS((x) => ({ ...x, ...p }));

  const loadGoals = async () => patch({ goals: (await api<any[]>("/goals")).map(mapGoal) });
  const loadHabits = async () => patch({ habits: (await api<any[]>(`/habits?on=${today()}`)).map(mapHabit) });
  const loadJournals = async () => patch({ journals: (await api<any[]>("/journals?limit=200")).map(mapJournal) });
  const loadMe = async () => {
    const m = await api<any>("/auth/me");
    userId.current = m.id;
    patch({ name: m.display_name ?? "", theme: m.theme, aiMode: m.ai_mode, done: m.onboarded });
  };
  const loadAll = async () => {
    await Promise.all([loadMe(), loadGoals(), loadHabits(), loadJournals()]);
    try { // activities & reflections belum punya endpoint backend -> sementara disimpan lokal per user
      const l = JSON.parse(localStorage.getItem("michia-local-" + userId.current) || "{}");
      patch({ activities: l.activities ?? [], reflections: l.reflections ?? [] });
    } catch {}
    setAuthed(true);
  };

  useEffect(() => {
    (async () => {
      if (getToken()) { try { await loadAll(); } catch { setToken(null); } }
      setReady(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => { document.documentElement.dataset.theme = s.theme; }, [s.theme]);

  const set = (f: (s: State) => State) =>
    setS((prev) => {
      const n = f(prev);
      try { localStorage.setItem("michia-local-" + userId.current, JSON.stringify({ activities: n.activities, reflections: n.reflections })); } catch {}
      return n;
    });

  const login = async (email: string, pw: string) => {
    const r = await api<{ access_token: string }>("/auth/login", { method: "POST", form: { username: email, password: pw } });
    setToken(r.access_token);
    await loadAll();
  };
  const register = async (email: string, pw: string, name: string) => {
    await api("/auth/register", { method: "POST", json: { email, password: pw, display_name: name || null } });
    await login(email, pw);
  };
  const logout = () => { setToken(null); setS(initial); setAuthed(false); };

  const act: Actions = {
    toggleHabit: async (id, done) => {
      setS((x) => ({ ...x, habits: x.habits.map((h) => (h.id === id ? { ...h, d: done, wk: h.wk + (done ? 1 : -1) } : h)) }));
      try { await api(`/habits/${id}/logs/${today()}`, { method: done ? "PUT" : "DELETE" }); } catch { await loadHabits(); }
    },
    addHabit: async (name, perWeek) => { await api("/habits", { method: "POST", json: { name, target_per_week: perWeek } }); await loadHabits(); },
    delHabit: async (id) => { await api(`/habits/${id}`, { method: "DELETE" }); await loadHabits(); },
    addJournal: async (text, ctx) => {
      await api("/journals", { method: "POST", json: { body: text, contexts: ctx.map((c) => CTX_ENUM[CONTEXTS.indexOf(c)]) } });
      await loadJournals();
    },
    setJournalCtx: async (id, ctx) => {
      await api(`/journals/${id}`, { method: "PATCH", json: { contexts: ctx.map((c) => CTX_ENUM[CONTEXTS.indexOf(c)]) } });
      await loadJournals();
    },
    delJournal: async (id) => { await api(`/journals/${id}`, { method: "DELETE" }); await loadJournals(); },
    addGoal: async (g) => {
      await api("/goals", { method: "POST", json: { name: g.n, why: g.w || null, priority: g.p.toLowerCase(), milestones: g.lines } });
      await loadGoals();
    },
    saveGoal: async (id, g) => {
      await api(`/goals/${id}`, { method: "PATCH", json: { name: g.n, why: g.w || null, priority: g.p.toLowerCase() } });
      const cur = await api<any>(`/goals/${id}`);
      const have = new Map<string, string>(cur.milestones.map((m: any) => [m.title, m.id]));
      for (const t of g.lines) if (!have.has(t)) await api(`/goals/${id}/milestones`, { method: "POST", json: { title: t } });
      for (const [t, mid] of have) if (!g.lines.includes(t)) await api(`/goals/${id}/milestones/${mid}`, { method: "DELETE" });
      await loadGoals();
    },
    delGoal: async (id) => { await api(`/goals/${id}`, { method: "DELETE" }); await Promise.all([loadGoals(), loadHabits()]); },
    toggleMs: async (gid, mid, done) => {
      setS((x) => ({ ...x, goals: x.goals.map((g) => (g.id === gid ? { ...g, ms: g.ms.map((m) => (m.id === mid ? { ...m, d: done } : m)) } : g)) }));
      try { await api(`/goals/${gid}/milestones/${mid}`, { method: "PATCH", json: { done } }); } catch { await loadGoals(); }
    },
    updateProfile: async (p) => {
      patch({ ...(p.name !== undefined && { name: p.name }), ...(p.theme && { theme: p.theme }), ...(p.aiMode && { aiMode: p.aiMode }), ...(p.done !== undefined && { done: p.done }) });
      await api("/auth/me", { method: "PATCH", json: {
        ...(p.name !== undefined && { display_name: p.name }), ...(p.theme && { theme: p.theme }),
        ...(p.aiMode && { ai_mode: p.aiMode }), ...(p.done !== undefined && { onboarded: p.done }) } });
    },
    deleteAccount: async () => {
      await api("/auth/me", { method: "DELETE" });
      try { localStorage.removeItem("michia-local-" + userId.current); } catch {}
      logout();
    },
  };

  return <C.Provider value={{ s, ready, authed, set, act, login, register, logout }}>{children}</C.Provider>;
}

export function useStore() {
  const c = useContext(C);
  if (!c) throw new Error("useStore harus dipakai di dalam <Provider>");
  return c;
}
