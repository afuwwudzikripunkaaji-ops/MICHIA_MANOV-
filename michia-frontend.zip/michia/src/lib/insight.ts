import { State, progress } from "./types";
import { detect } from "./detect";

export const weekJ = (s: State) => { const c = Date.now() - 6048e5; return s.journals.filter((j) => j.ts > c); };

// Simulasi berbasis aturan. TODO: ganti dengan insight dari LLM di backend.
export function genIns(s: State) {
  const w = weekJ(s);
  if (!w.length) return null;
  const m: Record<string, number> = {};
  let acts = 0;
  w.forEach((j) => detect(j.t).forEach((x) => {
    if (x.c >= 60) { acts++; if (s.goals.some((g) => g.n === x.g)) m[x.g] = (m[x.g] || 0) + 1; }
  }));
  const ks = Object.keys(m).sort((a, b) => m[b] - m[a]);
  const top = ks[0];
  const tg = s.goals.find((g) => g.n === top);
  const hi = s.goals.filter((g) => g.p === "High").sort((a, b) => progress(a) - progress(b))[0];
  const done = s.habits.filter((h) => h.d).length;
  const cc: Record<string, number> = {};
  w.forEach((j) => j.x.forEach((c) => (cc[c] = (cc[c] || 0) + 1)));
  const ck = Object.keys(cc).sort((a, b) => cc[b] - cc[a])[0];
  return {
    acts, links: ks.length, top, hi,
    obs: `Dalam 7 hari terakhir kamu menulis ${w.length} jurnal, dengan ${acts} aktivitas terdeteksi. Habit tercentang hari ini: ${done} dari ${s.habits.length}.`,
    pat: top ? `Aktivitasmu paling sering terkait goal “${top}” (${m[top]} kali). Ini dugaan dari kata kunci jurnal, bukan fakta.` : "Belum ada pola yang cukup jelas dari jurnal minggu ini.",
    imp: top && tg && tg.p !== "High" && hi && hi.n !== top ? `Goal prioritas tinggi “${hi.n}” (progress ${progress(hi)}%) sepertinya belum banyak tersentuh minggu ini.` : top ? "Aktivitasmu sejalan dengan goal yang kamu pilih." : "Belum bisa dikaitkan ke goal tertentu.",
    sug: hi ? `Coba sisihkan satu sesi kecil (20–30 menit) untuk “${hi.n}” minggu depan.` : "Coba buat satu goal prioritas tinggi supaya insight lebih terarah.",
    ref: top ? "Apakah pola itu memang terasa nyaman bagimu, atau ada yang ingin kamu ubah?" : "Hal apa dari minggu ini yang paling ingin kamu ingat?",
    ctx: ck ? `Konteks yang paling sering kamu catat: ${ck} (${cc[ck]} kali).` + (ck.includes("Tidur") ? " Ini mungkin berpengaruh ke energi dan konsistensi habit, tapi baru dugaan." : " Kalau terasa memengaruhi goal atau habit, mungkin layak diperhatikan.") : "",
  };
}
