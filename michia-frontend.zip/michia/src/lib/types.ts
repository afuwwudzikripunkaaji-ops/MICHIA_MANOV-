export type Priority = "High" | "Medium" | "Low";
export type AIMode = "off" | "ask" | "auto";
export type Milestone = { id: string; t: string; d: boolean };
export type Goal = { id: string; n: string; why: string; p: Priority; ms: Milestone[] };
export type Habit = { id: string; n: string; d: boolean; tpw: number; wk: number }; // d = sudah dicentang hari ini
export type Journal = { id: string; t: string; ts: number; x: string[] };
export type Activity = { id: string; t: string; src: "ai" | "manual"; goal: string; conf: number; w: string; st: "suggested" | "confirmed"; ts: number };
export type Reflection = { id: string; t: string; ts: number };
export type State = { name: string; theme: string; aiMode: AIMode; done: boolean; goals: Goal[]; habits: Habit[]; journals: Journal[]; activities: Activity[]; reflections: Reflection[] };

export const uid = () => Math.random().toString(36).slice(2, 9);
export const progress = (g: Goal) =>
  g.ms.length ? Math.round((g.ms.filter((m) => m.d).length / g.ms.length) * 100) : 0;

export const initial: State = {
  name: "", theme: "rose", aiMode: "auto", done: false,
  goals: [], habits: [], journals: [], activities: [], reflections: [],
};
