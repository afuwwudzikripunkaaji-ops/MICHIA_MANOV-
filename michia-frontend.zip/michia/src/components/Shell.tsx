"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ReactNode, useEffect } from "react";
import { useStore } from "@/lib/store";
import Onboarding from "./Onboarding";

const NAV = [["/", "🏠", "Home"], ["/journal", "📝", "Journal"], ["/activities", "⚡", "Activities"], ["/goals", "🎯", "Goals"], ["/habits", "🔁", "Habits"], ["/insights", "💡", "Insights"], ["/profile", "👤", "Profile"]];

export default function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const { s, ready, authed } = useStore();

  useEffect(() => {
    if (!ready) return;
    if (!authed && path !== "/login") router.replace("/login");
    if (authed && path === "/login") router.replace("/");
  }, [ready, authed, path, router]);

  if (!ready) return null;
  if (path === "/login") return <main>{children}</main>;
  if (!authed) return null;

  return (
    <>
      {!s.done && <Onboarding />}
      <nav>
        <div className="logo">MICHIA</div>
        <small>Live. Journal. Understand. Grow.</small>
        {NAV.map(([href, ic, label]) => (
          <Link key={href} href={href} className={path === href ? "on" : ""}>
            <b className="ic">{ic}</b> {label}
          </Link>
        ))}
      </nav>
      <main>{children}</main>
    </>
  );
}
