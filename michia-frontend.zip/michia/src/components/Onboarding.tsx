"use client";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { AIMode, Priority } from "@/lib/types";

const AREAS: Record<string, string> = {
  "Programming": "Lebih mahir programming", "Embedded System": "Menguasai Embedded System",
  "Akademik": "Studi & nilai lebih baik", "Olahraga": "Rutin olahraga", "Desain": "Belajar desain",
  "Keuangan": "Keuangan lebih sehat", "Karier": "Siap masuk dunia kerja", "Istirahat & tidur": "Tidur & istirahat cukup",
};
type GRow = { n: string; w: string; p: Priority };
type HRow = { n: string; f: string };
const MODES: [AIMode, string, string][] = [["off", "OFF", "Tanpa analisis AI"], ["ask", "ASK ME", "AI bekerja kalau kamu minta"], ["auto", "AUTOMATIC INSIGHT", "AI menyarankan setelah jurnal disimpan"]];

export default function Onboarding() {
  const { s, act } = useStore();
  const [busy, setBusy] = useState(false);
  const [i, setI] = useState(0);
  const [name, setName] = useState(s.name);
  const [areas, setAreas] = useState<string[]>([]);
  const [g, setG] = useState<GRow[]>([]);
  const [h, setH] = useState<HRow[]>([{ n: "", f: "4" }, { n: "", f: "3" }]);
  const [ai, setAi] = useState<AIMode>(s.aiMode);

  const upG = (k: number, v: Partial<GRow>) => setG(g.map((x, j) => (j === k ? { ...x, ...v } : x)));
  const upH = (k: number, v: Partial<HRow>) => setH(h.map((x, j) => (j === k ? { ...x, ...v } : x)));

  const finish = async () => {
    setBusy(true);
    try {
      for (const x of g.filter((x) => x.n.trim())) await act.addGoal({ n: x.n.trim(), w: x.w, p: x.p, lines: [] });
      for (const x of h.filter((x) => x.n.trim())) await act.addHabit(x.n.trim(), Math.min(7, Math.max(1, Number(x.f) || 4)));
      await act.updateProfile({ name, aiMode: ai, done: true });
    } finally { setBusy(false); }
  };
  const next = () => {
    if (i === 2 && !g.length) {
      const a = areas.slice(0, 3);
      setG((a.length ? a : [""]).map((x, k) => ({ n: AREAS[x] ?? "", w: "", p: (k === 0 ? "High" : "Medium") as Priority })));
    }
    if (i === 5) { finish(); return; }
    setI(i + 1);
  };

  return (
    <div className="ob"><div className="obc card">
      <div className="dots">{[0, 1, 2, 3, 4, 5].map((k) => <i key={k} className={k <= i ? "on" : ""} />)}</div>
      {i === 0 && <>
        <div className="logo big">MICHIA</div>
        <p className="muted" style={{ textAlign: "center" }}>MICHI (道, “jalan”) + AI</p>
        <h2 style={{ textAlign: "center" }}>Live. Journal. Understand. Grow.</h2>
        <p style={{ textAlign: "center" }}>Jurnal pengembangan diri buat mahasiswa. Kamu yang pegang kemudi, AI cuma bantu lihat jalannya. <b>AI Suggests. User Decides.</b></p>
      </>}
      {i === 1 && <><h2>Kenalan dulu yuk</h2><p className="sub">Biar sapaannya terasa personal.</p>
        <input className="in" placeholder="Nama panggilanmu" value={name} onChange={(e) => setName(e.target.value)} /></>}
      {i === 2 && <><h2>Apa yang ingin kamu kembangkan?</h2><p className="sub">Pilih satu atau lebih, bebas.</p>
        <div className="chips">{Object.keys(AREAS).map((a) => (
          <button key={a} className={"chip" + (areas.includes(a) ? " on" : "")}
            onClick={() => setAreas((v) => (v.includes(a) ? v.filter((x) => x !== a) : [...v, a]))}>{a}</button>))}</div></>}
      {i === 3 && <><h2>Buat goal & tentukan prioritas</h2><p className="sub">Edit sesukamu. Kosongkan nama kalau tidak mau dipakai.</p>
        {g.map((x, k) => (
          <div className="grow" key={k}>
            <input className="in" placeholder="Nama goal" value={x.n} onChange={(e) => upG(k, { n: e.target.value })} />
            <input className="in" placeholder="Kenapa ini penting buatmu? (Why)" value={x.w} onChange={(e) => upG(k, { w: e.target.value })} />
            <select className="in" value={x.p} onChange={(e) => upG(k, { p: e.target.value as Priority })}><option>High</option><option>Medium</option><option>Low</option></select>
          </div>))}
        <button className="btn ghost" onClick={() => setG([...g, { n: "", w: "", p: "Medium" }])}>+ Tambah goal</button></>}
      {i === 4 && <><h2>Bangun kebiasaan (opsional)</h2><p className="sub">Tidak semua goal perlu habit. Mulai dari yang kecil.</p>
        {h.map((x, k) => (
          <div className="grow" key={k}>
            <input className="in" placeholder="Contoh: Coding 1 jam" value={x.n} onChange={(e) => upH(k, { n: e.target.value })} />
            <input className="in" type="number" min={1} max={7} value={x.f} onChange={(e) => upH(k, { f: e.target.value })} />
            <small className="muted">kali per minggu</small>
          </div>))}</>}
      {i === 5 && <><h2>Preferensi AI</h2><p className="sub">Bisa kamu ubah kapan saja di Profile.</p>
        {MODES.map(([v, l, d]) => (
          <label key={v} className="opt"><input type="radio" name="obai" checked={ai === v} onChange={() => setAi(v)} /><b>{l}</b> — {d}</label>))}</>}
      <div className="nav2">
        {i > 0 ? <button className="btn ghost" onClick={() => setI(i - 1)}>Kembali</button> : <span />}
        <button className="btn" onClick={next} disabled={busy}>{i === 0 ? "Mulai" : i === 5 ? "Masuk ke Dashboard" : "Lanjut"}</button>
      </div>
    </div></div>
  );
}
