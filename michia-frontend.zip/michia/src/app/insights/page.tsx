"use client";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { uid } from "@/lib/types";
import { genIns, weekJ } from "@/lib/insight";

export default function Insights() {
  const { s, set } = useStore();
  const [go, setGo] = useState(false);
  const [t, setT] = useState("");
  const [fu, setFu] = useState("");
  const off = s.aiMode === "off";
  const o = off ? null : genIns(s);
  const hp = s.habits.length ? Math.round((s.habits.filter((h) => h.d).length / s.habits.length) * 100) + "%" : "-";
  const stats: [string | number, string][] = [[weekJ(s).length, "Journal entries"], [off ? "-" : o?.acts ?? 0, "Activities terdeteksi"], [off ? "-" : o?.links ?? 0, "Goals terdukung"], [hp, "Habit hari ini"]];
  const rows: [string, string][] = o ? [["Observation", o.obs], ["Pattern", o.pat], ["Impact", o.imp], ...(o.ctx ? [["Context", o.ctx] as [string, string]] : []), ["Suggestion", o.sug], ["Reflection", o.ref]] : [];
  const saveR = () => {
    if (!t.trim()) return;
    set((st) => ({ ...st, reflections: [{ id: uid(), t: t.trim(), ts: Date.now() }, ...st.reflections] }));
    setFu(off ? "" : "Terima kasih sudah berefleksi. Satu langkah kecil apa yang ingin kamu coba minggu depan?");
    setT("");
  };
  return (
    <>
      <h1>Insights</h1>
      <p className="sub">Dugaan untuk membantu refleksi, bukan penilaian. Kamu yang memutuskan.</p>
      <div className="card"><h2>📅 Your Week</h2>
        <div className="grid">
          {stats.map(([v, l]) => <div className="stat" key={l}><b>{v}</b>{l}</div>)}
          <div className="stat w">Area terkuat<b>{o?.top || "-"}</b></div>
          <div className="stat w">Perlu perhatian<b>{o?.hi?.n || "-"}</b></div>
        </div>
      </div>
      <div className="card"><h2>💡 AI Insight</h2>
        {off ? <p className="sub" style={{ margin: 0 }}>AI sedang OFF, jadi insight tidak dibuat. Aktifkan di Profile kapan pun kamu mau.</p>
          : s.aiMode === "ask" && !go ? <button className="btn" onClick={() => setGo(true)}>✨ Analyze with AI</button>
          : !o ? <p className="sub" style={{ margin: 0 }}>Belum ada jurnal dalam 7 hari terakhir. Tulis satu jurnal kecil dulu, nanti insightnya muncul.</p>
          : <>{rows.map(([k, v]) => <p key={k} style={{ margin: "0 0 10px" }}><b>{k}</b><br />{v}</p>)}
            <small className="muted">Data yang dipakai: jurnal 7 hari terakhir, habit, dan progress goal. AI bisa dimatikan di Profile.</small></>}
      </div>
      <div className="card"><h2>🪞 Weekly Reflection</h2>
        <p className="sub" style={{ margin: "0 0 8px" }}>Menurutmu minggu ini bagaimana?</p>
        <textarea value={t} onChange={(e) => setT(e.target.value)} placeholder="Tulis bebas, tidak ada jawaban benar atau salah..." />
        <div style={{ marginTop: 10 }}><button className="btn" onClick={saveR}>Simpan refleksi</button></div>
        {fu && <p style={{ fontSize: 14 }}>{fu}</p>}
        {s.reflections.map((r) => (
          <div key={r.id} style={{ borderTop: "1px solid var(--border)", padding: "8px 0", fontSize: 14 }}>
            <b className="muted" style={{ fontSize: 12 }}>{new Date(r.ts).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })}</b><br />{r.t}
          </div>))}
      </div>
    </>
  );
}
