"use client";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { progress } from "@/lib/types";
import { genIns } from "@/lib/insight";

export default function Home() {
  const { s, act } = useStore();
  const h = new Date().getHours();
  const o = s.aiMode === "off" ? null : genIns(s);
  const hi = h < 11 ? "Selamat pagi" : h < 15 ? "Selamat siang" : h < 19 ? "Selamat sore" : "Selamat malam";
  return (
    <>
      <h1>{hi}{s.name ? `, ${s.name}` : ""} 👋</h1>
      <p className="sub">Apa yang terjadi hari ini?</p>
      <div className="card row">
        <span>Tulis aja bebas, kapan pun kamu mau.</span>
        <Link className="btn" href="/journal">+ Write Journal</Link>
      </div>
      <div className="grid">
        <div className="card">
          <h2>🎯 Priority Goals</h2>
          {s.goals.filter((g) => g.p === "High").map((g) => (
            <div key={g.id}>
              <div className="row"><span>{g.n}</span><b>{progress(g)}%</b></div>
              <div className="bar"><i style={{ width: progress(g) + "%" }} /></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h2>🔁 Habits hari ini</h2>
          {s.habits.map((x) => (
            <label key={x.id} className="hab">
              <input type="checkbox" checked={x.d}
                onChange={(e) => act.toggleHabit(x.id, e.target.checked)} />
              {x.n}
            </label>
          ))}
        </div>
      </div>
      <div className="card">
        <h2>💡 Today&apos;s Insight</h2>
        {s.aiMode === "off" ? <p className="sub" style={{ margin: "0 0 10px" }}>AI sedang OFF. Aktifkan di Profile kalau mau insight.</p>
          : o ? <p style={{ margin: "0 0 10px" }}>{o.obs}<br /><b>Refleksi:</b> {o.ref}</p>
          : <p className="sub" style={{ margin: "0 0 10px" }}>Belum ada jurnal 7 hari terakhir. Tulis satu jurnal kecil dulu.</p>}
        <Link className="btn ghost" href="/insights">Lihat Insights</Link>
      </div>
    </>
  );
}
