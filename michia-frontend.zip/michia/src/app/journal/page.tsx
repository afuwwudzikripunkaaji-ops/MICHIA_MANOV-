"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";
import { uid } from "@/lib/types";
import { detect, detectCtx, CONTEXTS } from "@/lib/detect";

export default function Journal() {
  const { s, set, act } = useStore();
  const router = useRouter();
  const [t, setT] = useState("");
  const [x, setX] = useState<string[]>([]);
  const [last, setLast] = useState("");
  const [sug, setSug] = useState(false);

  const save = async () => {
    if (!t.trim()) return;
    await act.addJournal(t.trim(), x);
    setLast(t); setT(""); setX([]); setSug(s.aiMode === "auto");
  };
  const have = s.journals[0]?.x ?? [];
  const pc = sug ? detectCtx(last).filter((c) => !have.includes(c.n)) : [];
  const resolve = (st: "confirmed" | "suggested") => {
    const names = s.goals.map((g) => g.n);
    const acts = detect(last).filter((d) => d.a !== "Aktivitas umum")
      .map((d) => ({ id: uid(), t: d.a, src: "ai" as const, goal: names.includes(d.g) ? d.g : "", conf: d.c, w: d.w, st, ts: Date.now() }));
    set((sx) => ({ ...sx, activities: [...acts, ...sx.activities] }));
    if (pc.length && s.journals[0]) act.setJournalCtx(s.journals[0].id, [...s.journals[0].x, ...pc.map((c) => c.n)]);
    setSug(false);
    if (st === "suggested") router.push("/activities");
  };

  return (
    <>
      <h1>Journal</h1>
      <p className="sub">Bebas, tidak harus tiap hari, tidak ada template.</p>
      <div className="card">
        <textarea value={t} onChange={(e) => setT(e.target.value)} placeholder="Hari ini praktikum ESP32, sensor I2C sempat tidak terbaca..." />
        <small className="muted">Life Context (opsional): ada yang memengaruhi harimu?</small>
        <div className="chips">
          {CONTEXTS.map((c) => (
            <button key={c} className={"chip" + (x.includes(c) ? " on" : "")}
              onClick={() => setX((v) => (v.includes(c) ? v.filter((i) => i !== c) : [...v, c]))}>{c}</button>
          ))}
        </div>
        <div className="row">
          <span className="muted">AI: {s.aiMode.toUpperCase()}</span>
          <button className="btn" onClick={save}>Simpan</button>
        </div>
        {s.aiMode === "ask" && last && !sug && (
          <button className="btn ghost" style={{ marginTop: 10 }} onClick={() => setSug(true)}>✨ Analyze with AI</button>
        )}
        {sug && s.aiMode !== "off" && (
          <div className="sug">
            <b>✨ Aku menemukan sesuatu di jurnalmu</b>
            {detect(last).map((d) => (
              <div key={d.a}>
                <p>☑ {d.a} → <b>{d.g}</b> <span className="tag">{d.c}%</span></p>
                <details><summary className="muted">Why?</summary><p className="muted">{d.w}</p></details>
              </div>
            ))}
            {pc.map((c) => <p key={c.n}>☑ Context: <b>{c.n}</b> <span className="tag">{c.c}%</span></p>)}
            <div className="gap">
              <button className="btn" onClick={() => resolve("confirmed")}>Confirm</button>
              <button className="btn ghost" onClick={() => resolve("suggested")}>Edit</button>
              <button className="btn ghost" onClick={() => setSug(false)}>Ignore</button>
            </div>
          </div>
        )}
      </div>
      <div className="card">
        <h2>Timeline — Your Journey</h2>
        <div className="tl">
          {s.journals.length === 0 && <div><b>Belum ada jurnal</b>Tulis satu kalimat pun cukup.</div>}
          {s.journals.map((j) => (
            <div key={j.id}>
              <b>{new Date(j.ts).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })} · Journal{" "}
                <a href="#" onClick={(e) => { e.preventDefault(); act.delJournal(j.id); }}>hapus</a>
              </b>
              {j.t}
              {j.x.length > 0 && <div>{j.x.map((c) => <span key={c} className="tag h">{c} </span>)}</div>}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
