import "./globals.css";
import { Provider } from "@/lib/store";
import Shell from "@/components/Shell";

export const metadata = { title: "MICHIA", description: "Live. Journal. Understand. Grow." };
export const viewport = { width: "device-width", initialScale: 1, viewportFit: "cover" as const };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>
        <Provider>
          <Shell>{children}</Shell>
        </Provider>
      </body>
    </html>
  );
}
