"use client";
import { useState } from "react";
import { useStore } from "@/lib/store";

export default function Login() {
  const { login, register } = useStore();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState(""); const [pw, setPw] = useState(""); const [name, setName] = useState("");
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);

  const submit = async () => {
    setErr(""); setBusy(true);
    try { mode === "login" ? await login(email, pw) : await register(email, pw, name); }
    catch (e) { setErr(e instanceof Error ? e.message : "Terjadi kesalahan"); }
    finally { setBusy(false); }
  };

  return (
    <div style={{ maxWidth: 420, margin: "8vh auto 0" }}>
      <div className="logo big">MICHIA</div>
      <p className="muted" style={{ textAlign: "center" }}>Live. Journal. Understand. Grow.</p>
      <div className="card">
        <h2>{mode === "login" ? "Masuk" : "Buat akun"}</h2>
        {mode === "register" && <input className="in" placeholder="Nama panggilan (opsional)" value={name} onChange={(e) => setName(e.target.value)} />}
        <input className="in" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className="in" type="password" placeholder="Password (min. 8 karakter)" value={pw}
          onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} />
        {err && <p style={{ color: "crimson", fontSize: 14 }}>{err}</p>}
        <div className="row" style={{ marginTop: 10 }}>
          <button className="btn ghost" onClick={() => { setMode(mode === "login" ? "register" : "login"); setErr(""); }}>
            {mode === "login" ? "Belum punya akun?" : "Sudah punya akun?"}
          </button>
          <button className="btn" onClick={submit} disabled={busy}>{busy ? "..." : mode === "login" ? "Masuk" : "Daftar"}</button>
        </div>
      </div>
    </div>
  );
}
