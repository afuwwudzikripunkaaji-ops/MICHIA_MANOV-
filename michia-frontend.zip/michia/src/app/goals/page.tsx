"use client";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Goal, Priority, progress } from "@/lib/types";

export default function Goals() {
  const { s, act } = useStore();
  const [eid, setEid] = useState<string | null>(null);
  const [n, setN] = useState(""); const [w, setW] = useState("");
  const [p, setP] = useState<Priority>("Medium"); const [ms, setMs] = useState("");

  const reset = () => { setEid(null); setN(""); setW(""); setMs(""); setP("Medium"); };
  const edit = (g: Goal) => { setEid(g.id); setN(g.n); setW(g.why === "(belum diisi)" ? "" : g.why); setP(g.p); setMs(g.ms.map((m) => m.t).join("\n")); window.scrollTo(0, 0); };
  const save = async () => {
    if (!n.trim()) return;
    const lines = ms.split("\n").map((x) => x.trim()).filter(Boolean);
    const g = { n: n.trim(), w, p, lines };
    if (eid) await act.saveGoal(eid, g); else await act.addGoal(g);
    reset();
  };
  const toggle = (gid: string, mid: string, v: boolean) => act.toggleMs(gid, mid, v);
  const del = (id: string) => confirm("Hapus goal ini?") && act.delGoal(id);

  return (
    <>
      <h1>Goals</h1>
      <p className="sub">Bebas jumlahnya, kamu yang menentukan prioritas. Progress dihitung dari milestone yang dicentang.</p>
      <div className="card">
        <h2>{eid ? "Edit goal" : "+ Goal baru"}</h2>
        <input className="in" placeholder="Nama goal" value={n} onChange={(e) => setN(e.target.value)} />
        <input className="in" placeholder="Why — kenapa ini penting?" value={w} onChange={(e) => setW(e.target.value)} />
        <select className="in" value={p} onChange={(e) => setP(e.target.value as Priority)}><option>High</option><option>Medium</option><option>Low</option></select>
        <textarea placeholder="Milestone, satu per baris" value={ms} onChange={(e) => setMs(e.target.value)} />
        <div className="gap"><button className="btn" onClick={save}>Simpan goal</button>{eid && <button className="btn ghost" onClick={reset}>Batal</button>}</div>
      </div>
      {s.goals.map((g) => {
        const rec = s.activities.filter((a) => a.goal === g.n && a.st === "confirmed").slice(0, 3);
        return (
          <div className="card" key={g.id}>
            <div className="row">
              <h2 style={{ margin: 0 }}>{g.n}</h2>
              <span><span className={"tag" + (g.p === "High" ? "" : " h")}>{g.p.toUpperCase()}</span>{" "}
                <button className="btn ghost" onClick={() => edit(g)}>Edit</button>{" "}
                <button className="btn ghost" onClick={() => del(g.id)}>Hapus</button></span>
            </div>
            <p className="sub" style={{ margin: "6px 0" }}>Why: {g.why}</p>
            <div className="row"><span>Progress</span><b>{progress(g)}%</b></div>
            <div className="bar"><i style={{ width: progress(g) + "%" }} /></div>
            {g.ms.map((m) => (
              <label key={m.id} className="hab"><input type="checkbox" checked={m.d} onChange={(e) => toggle(g.id, m.id, e.target.checked)} />{m.t}</label>
            ))}
            {rec.length > 0 && <div className="muted" style={{ marginTop: 8, fontSize: 13 }}><b>Recent activities</b><br />{rec.map((a) => <div key={a.id}>• {a.t}</div>)}</div>}
          </div>
        );
      })}
    </>
  );
}
