"use client";
import { useState } from "react";
import { useStore } from "@/lib/store";

export default function Habits() {
  const { s, act } = useStore();
  const [n, setN] = useState(""); const [f, setF] = useState("4");
  const add = async () => {
    if (!n.trim()) return;
    await act.addHabit(n.trim(), Math.min(7, Math.max(1, Number(f) || 4)));
    setN("");
  };
  return (
    <>
      <h1>Habits</h1>
      <p className="sub">Fokus ke perkembangan, bukan takut kehilangan streak.</p>
      <div className="card">
        {s.habits.length === 0 && <p className="sub" style={{ margin: 0 }}>Belum ada habit.</p>}
        {s.habits.map((x) => (
          <div className="row" key={x.id}>
            <label className="hab">
              <input type="checkbox" checked={x.d} onChange={(e) => act.toggleHabit(x.id, e.target.checked)} />
              {x.n} <span className="muted" style={{ fontSize: 13 }}>· {x.wk}/{x.tpw} minggu ini</span>
            </label>
            <button className="btn ghost" onClick={() => act.delHabit(x.id)}>×</button>
          </div>
        ))}
      </div>
      <div className="card">
        <h2>+ Habit baru</h2>
        <div className="row">
          <input className="in" placeholder="Contoh: Baca 30 menit" value={n} onChange={(e) => setN(e.target.value)} />
          <input className="in" type="number" min={1} max={7} value={f} onChange={(e) => setF(e.target.value)} style={{ width: 80 }} />
          <button className="btn" onClick={add}>Tambah</button>
        </div>
        <small className="muted">kali per minggu</small>
      </div>
    </>
  );
}
