"use client";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { THEMES } from "@/lib/themes";
import { AIMode } from "@/lib/types";

const MODES: [AIMode, string, string][] = [
  ["off", "OFF", "jurnal tanpa analisis AI"],
  ["ask", "ASK AI", "AI bekerja kalau kamu minta"],
  ["auto", "AUTOMATIC INSIGHT", "AI menyarankan setelah jurnal disimpan"],
];

export default function Profile() {
  const { s, act, logout } = useStore();
  const [name, setName] = useState(s.name);
  const [sure, setSure] = useState(false);
  return (
    <>
      <h1>Profile</h1>
      <p className="sub">Atur ruang pribadimu.</p>
      <div className="card row"><span>Onboarding</span><button className="btn ghost" onClick={() => act.updateProfile({ done: false })}>Ulangi onboarding</button></div>
      <div className="card">
        <h2>Nama panggilan</h2>
        <input className="in" value={name} onChange={(e) => setName(e.target.value)} onBlur={() => name !== s.name && act.updateProfile({ name })} placeholder="Namamu" />
      </div>
      <div className="card">
        <h2>🎨 Your Space — Tema warna</h2>
        <div className="themes">
          {THEMES.map((t) => (
            <button key={t.id} className={"th" + (s.theme === t.id ? " on" : "")} onClick={() => act.updateProfile({ theme: t.id })}>
              <div className="sw">{t.c.map((c) => <i key={c} style={{ background: c }} />)}</div>
              {t.n}
            </button>
          ))}
        </div>
      </div>
      <div className="card">
        <h2>✨ AI Assistance</h2>
        {MODES.map(([v, l, d]) => (
          <label key={v} className="opt">
            <input type="radio" name="ai" checked={s.aiMode === v} onChange={() => act.updateProfile({ aiMode: v })} />
            <b>{l}</b> — {d}
          </label>
        ))}
        <p className="sub" style={{ margin: "8px 0 0" }}>AI Suggests. User Decides.</p>
      </div>
      <div className="card">
        <h2>Akun</h2>
        <div className="gap" style={{ marginTop: 0 }}>
          <button className="btn ghost" onClick={logout}>Keluar</button>
          {sure
            ? <button className="btn" onClick={() => act.deleteAccount()}>Yakin hapus akun & semua data?</button>
            : <button className="btn ghost" onClick={() => setSure(true)}>Hapus akun</button>}
        </div>
      </div>
    </>
  );
}
