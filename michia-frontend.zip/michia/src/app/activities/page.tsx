"use client";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Activity, uid } from "@/lib/types";

type F = "all" | "suggested" | "confirmed";

export default function Activities() {
  const { s, set } = useStore();
  const [t, setT] = useState("");
  const [g, setG] = useState("");
  const [f, setF] = useState<F>("all");
  const ns = s.activities.filter((a) => a.st === "suggested").length;
  const list = s.activities.filter((a) => f === "all" || a.st === f);

  const add = () => {
    if (!t.trim()) return;
    set((st) => ({ ...st, activities: [{ id: uid(), t: t.trim(), src: "manual", goal: g, conf: 0, w: "", st: "confirmed", ts: Date.now() }, ...st.activities] }));
    setT("");
  };
  const upd = (id: string, p: Partial<Activity>) => set((st) => ({ ...st, activities: st.activities.map((a) => (a.id === id ? { ...a, ...p } : a)) }));
  const del = (id: string) => set((st) => ({ ...st, activities: st.activities.filter((a) => a.id !== id) }));
  const goalSel = (v: string, on: (x: string) => void) => (
    <select className="in" value={v} onChange={(e) => on(e.target.value)}>
      <option value="">(belum terhubung ke goal)</option>
      {s.goals.map((x) => <option key={x.id}>{x.n}</option>)}
    </select>
  );

  return (
    <>
      <h1>Activities</h1>
      <p className="sub">Apa yang benar-benar kamu lakukan, manual atau hasil deteksi AI. Kamu yang menentukan hubungannya ke goal.</p>
      <div className="card">
        <h2>+ Catat aktivitas</h2>
        <input className="in" placeholder="Contoh: Praktikum ESP32 2 jam" value={t} onChange={(e) => setT(e.target.value)} />
        {goalSel(g, setG)}
        <button className="btn" onClick={add}>Tambah</button>
      </div>
      <div className="chips">
        {([["all", "Semua"], ["suggested", `Perlu konfirmasi (${ns})`], ["confirmed", "Dikonfirmasi"]] as [F, string][]).map(([k, l]) => (
          <button key={k} className={"chip" + (f === k ? " on" : "")} onClick={() => setF(k)}>{l}</button>
        ))}
      </div>
      {list.length === 0 && <div className="card"><p className="sub" style={{ margin: 0 }}>Belum ada aktivitas di sini. Catat manual di atas, atau tulis jurnal dan biarkan AI menyarankan.</p></div>}
      {list.map((a) => (
        <div className="card" key={a.id}>
          <div className="row">
            <b>{a.t}</b>
            <span><span className={"tag" + (a.src === "ai" ? "" : " h")}>{a.src === "ai" ? "AI" : "Manual"}</span>{a.st === "suggested" && <> <span className="tag h">Perlu konfirmasi</span></>}</span>
          </div>
          <div className="muted" style={{ fontSize: 13, margin: "4px 0" }}>
            {new Date(a.ts).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })}{a.src === "ai" && a.conf ? ` · keyakinan ${a.conf}%` : ""}
          </div>
          {a.st === "suggested" && a.w && <div className="muted" style={{ fontSize: 12 }}>Why: {a.w}</div>}
          {goalSel(a.goal, (v) => upd(a.id, { goal: v }))}
          <div className="gap">
            {a.st === "suggested"
              ? <><button className="btn" onClick={() => upd(a.id, { st: "confirmed" })}>Confirm</button><button className="btn ghost" onClick={() => del(a.id)}>Ignore</button></>
              : <button className="btn ghost" onClick={() => del(a.id)}>Hapus</button>}
          </div>
        </div>
      ))}
    </>
  );
}
