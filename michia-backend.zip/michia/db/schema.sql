-- MICHIA — skema awal PostgreSQL (v0.1)
-- Prinsip: user memiliki datanya. Hapus user => semua datanya ikut terhapus (ON DELETE CASCADE).
-- Prinsip AI: hubungan hasil AI selalu punya status (suggested/confirmed/rejected); keputusan user = sumber kebenaran.

CREATE EXTENSION IF NOT EXISTS pgcrypto;  -- untuk gen_random_uuid()

CREATE TYPE priority_level AS ENUM ('high', 'medium', 'low');
CREATE TYPE ai_mode        AS ENUM ('off', 'ask', 'auto');
CREATE TYPE source_type    AS ENUM ('manual', 'ai');
CREATE TYPE link_status    AS ENUM ('suggested', 'confirmed', 'rejected');
CREATE TYPE life_context   AS ENUM ('mood', 'sleep_health', 'finance', 'social', 'career', 'study');

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,              -- jangan pernah simpan password asli
  display_name  TEXT,
  theme         TEXT NOT NULL DEFAULT 'rose',
  onboarded     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ai_settings (
  user_id     UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  mode        ai_mode NOT NULL DEFAULT 'auto',
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE journals (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_journals_user_time ON journals (user_id, created_at DESC);

-- Life Context: lapisan tambahan, opsional. source/status mengikuti prinsip AI Suggests, User Decides.
CREATE TABLE journal_contexts (
  journal_id  UUID NOT NULL REFERENCES journals(id) ON DELETE CASCADE,
  context     life_context NOT NULL,
  source      source_type  NOT NULL DEFAULT 'manual',
  status      link_status  NOT NULL DEFAULT 'confirmed',
  confidence  SMALLINT CHECK (confidence BETWEEN 0 AND 100),
  PRIMARY KEY (journal_id, context)
);

CREATE TABLE goals (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  why         TEXT,
  priority    priority_level NOT NULL DEFAULT 'medium',
  deadline    DATE,
  archived    BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_goals_user ON goals (user_id) WHERE NOT archived;

-- Progress goal dihitung dari milestone yang selesai (rumus MVP); bukan kolom tersimpan.
CREATE TABLE milestones (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id     UUID NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  done        BOOLEAN NOT NULL DEFAULT FALSE,
  position    INT NOT NULL DEFAULT 0
);
CREATE INDEX idx_milestones_goal ON milestones (goal_id, position);

CREATE TABLE habits (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  target_per_week SMALLINT NOT NULL DEFAULT 4 CHECK (target_per_week BETWEEN 1 AND 7),
  goal_id         UUID REFERENCES goals(id) ON DELETE SET NULL,  -- habit boleh tanpa goal
  archived        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Riwayat centang habit (satu baris per hari yang dikerjakan).
CREATE TABLE habit_logs (
  habit_id    UUID NOT NULL REFERENCES habits(id) ON DELETE CASCADE,
  log_date    DATE NOT NULL,
  PRIMARY KEY (habit_id, log_date)
);

CREATE TABLE activities (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  journal_id  UUID REFERENCES journals(id) ON DELETE SET NULL,  -- asal aktivitas (jika dari jurnal)
  title       TEXT NOT NULL,
  source      source_type NOT NULL DEFAULT 'manual',
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_activities_user_time ON activities (user_id, occurred_at DESC);

CREATE TABLE activity_goal_links (
  activity_id UUID NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  goal_id     UUID NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
  source      source_type NOT NULL DEFAULT 'manual',
  status      link_status NOT NULL DEFAULT 'confirmed',
  confidence  SMALLINT CHECK (confidence BETWEEN 0 AND 100),
  why         TEXT,                       -- penjelasan "Why?" dari AI
  PRIMARY KEY (activity_id, goal_id)
);

CREATE TABLE activity_habit_links (
  activity_id UUID NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  habit_id    UUID NOT NULL REFERENCES habits(id) ON DELETE CASCADE,
  source      source_type NOT NULL DEFAULT 'manual',
  status      link_status NOT NULL DEFAULT 'confirmed',
  confidence  SMALLINT CHECK (confidence BETWEEN 0 AND 100),
  why         TEXT,
  PRIMARY KEY (activity_id, habit_id)
);

CREATE TABLE ai_insights (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period_start DATE NOT NULL,
  period_end   DATE NOT NULL,
  observation TEXT,
  pattern     TEXT,
  impact      TEXT,
  suggestion  TEXT,
  reflection  TEXT,                       -- pertanyaan refleksi untuk user
  data_used   JSONB,                      -- transparansi: data apa yang dipakai AI
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_insights_user_time ON ai_insights (user_id, created_at DESC);

-- Jawaban user pada Weekly Reflection.
CREATE TABLE reflections (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reminders (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  habit_id    UUID REFERENCES habits(id) ON DELETE CASCADE,
  message     TEXT,
  remind_at   TIME NOT NULL,
  days        SMALLINT[] NOT NULL DEFAULT '{1,2,3,4,5,6,7}',  -- 1=Senin ... 7=Minggu
  enabled     BOOLEAN NOT NULL DEFAULT TRUE
);
