# MICHIA API (FastAPI)

Setup (dari folder `backend/`):

    python -m venv .venv
    .venv\Scripts\activate          # Windows  (Mac/Linux: source .venv/bin/activate)
    pip install -r requirements.txt
    createdb michia
    psql -d michia -f ../db/schema.sql
    copy .env.example .env          # Mac/Linux: cp .env.example .env, lalu isi SECRET_KEY
    uvicorn app.main:app --reload

Buka http://localhost:8000/docs untuk mencoba endpoint. Jalankan tes: `pytest`.
