import uuid
from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field

AIMode = Literal["off", "ask", "auto"]
Theme = Literal["rose", "ocean", "lime", "sky", "burgundy"]


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    display_name: str | None = Field(default=None, max_length=60)


class UserOut(BaseModel):
    id: uuid.UUID
    email: EmailStr
    display_name: str | None
    theme: str
    onboarded: bool
    ai_mode: AIMode


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class MeUpdate(BaseModel):
    display_name: str | None = Field(default=None, max_length=60)
    theme: Theme | None = None
    onboarded: bool | None = None
    ai_mode: AIMode | None = None


Priority = Literal["high", "medium", "low"]
LifeContext = Literal["mood", "sleep_health", "finance", "social", "career", "study"]


class ContextOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    context: str
    source: str
    status: str
    confidence: int | None


class JournalIn(BaseModel):
    body: str = Field(min_length=1, max_length=20000)
    contexts: list[LifeContext] = []


class JournalUpdate(BaseModel):
    body: str | None = Field(default=None, min_length=1, max_length=20000)
    contexts: list[LifeContext] | None = None


class JournalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    body: str
    created_at: datetime
    contexts: list[ContextOut]


class MilestoneOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    title: str
    done: bool
    position: int


class MilestoneIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)


class MilestoneUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=200)
    done: bool | None = None


class GoalIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    why: str | None = Field(default=None, max_length=500)
    priority: Priority = "medium"
    deadline: date | None = None
    milestones: list[str] = []


class GoalUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    why: str | None = Field(default=None, max_length=500)
    priority: Priority | None = None
    deadline: date | None = None
    archived: bool | None = None


class GoalOut(BaseModel):
    id: uuid.UUID
    name: str
    why: str | None
    priority: str
    deadline: date | None
    archived: bool
    created_at: datetime
    progress: int  # % milestone selesai (rumus MVP)
    milestones: list[MilestoneOut]


class HabitIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    target_per_week: int = Field(default=4, ge=1, le=7)
    goal_id: uuid.UUID | None = None


class HabitUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    target_per_week: int | None = Field(default=None, ge=1, le=7)
    goal_id: uuid.UUID | None = None
    archived: bool | None = None


class HabitOut(BaseModel):
    id: uuid.UUID
    name: str
    target_per_week: int
    goal_id: uuid.UUID | None
    archived: bool
    done_today: bool
    done_this_week: int
