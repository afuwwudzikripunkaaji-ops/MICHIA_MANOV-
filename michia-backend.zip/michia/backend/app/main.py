from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .routers import auth, goals, habits, journals

app = FastAPI(title="MICHIA API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(journals.router)
app.include_router(goals.router)
app.include_router(habits.router)


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}
