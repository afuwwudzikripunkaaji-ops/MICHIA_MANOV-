from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")

    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/michia"
    secret_key: str  # wajib diisi di .env
    access_token_minutes: int = 60 * 24
    cors_origins: list[str] = ["http://localhost:3000"]


settings = Settings()
