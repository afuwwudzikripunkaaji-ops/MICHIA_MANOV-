from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from .database import get_db
from .models import User
from .security import decode_access_token

oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)) -> User:
    uid = decode_access_token(token)
    user = db.get(User, uid) if uid else None
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token tidak valid atau kedaluwarsa",
                            headers={"WWW-Authenticate": "Bearer"})
    return user


def get_owned(db: Session, model, obj_id, user: User, name: str = "Data"):
    """Ambil baris milik user yang sedang login; 404 kalau tidak ada atau milik orang lain."""
    obj = db.scalar(select(model).where(model.id == obj_id, model.user_id == user.id))
    if not obj:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"{name} tidak ditemukan")
    return obj
