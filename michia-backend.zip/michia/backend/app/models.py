"""Model SQLAlchemy. Tabel dibuat lewat db/schema.sql (jangan pakai create_all di produksi).
Baru users + ai_settings; tabel lain (journals, goals, dst.) ditambah bertahap."""
import uuid
from datetime import datetime

from datetime import date

from sqlalchemy import Boolean, Date, DateTime, Enum, ForeignKey, Integer, SmallInteger, String, Text, Uuid, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base

AI_MODES = ("off", "ask", "auto")
PRIORITIES = ("high", "medium", "low")
CONTEXTS = ("mood", "sleep_health", "finance", "social", "career", "study")
SOURCES = ("manual", "ai")
LINK_STATUSES = ("suggested", "confirmed", "rejected")


class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    email: Mapped[str] = mapped_column(String, unique=True)
    password_hash: Mapped[str] = mapped_column(String)
    display_name: Mapped[str | None] = mapped_column(String)
    theme: Mapped[str] = mapped_column(String, default="rose")
    onboarded: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    ai_settings: Mapped["AISettings"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )


class AISettings(Base):
    __tablename__ = "ai_settings"

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    mode: Mapped[str] = mapped_column(Enum(*AI_MODES, name="ai_mode", create_type=False), default="auto")

    user: Mapped[User] = relationship(back_populates="ai_settings")


def _uid_pk():
    return mapped_column(Uuid, primary_key=True, default=uuid.uuid4)


def _owner():
    return mapped_column(ForeignKey("users.id", ondelete="CASCADE"))


class Journal(Base):
    __tablename__ = "journals"

    id: Mapped[uuid.UUID] = _uid_pk()
    user_id: Mapped[uuid.UUID] = _owner()
    body: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    contexts: Mapped[list["JournalContext"]] = relationship(cascade="all, delete-orphan", lazy="selectin")


class JournalContext(Base):
    __tablename__ = "journal_contexts"

    journal_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("journals.id", ondelete="CASCADE"), primary_key=True)
    context: Mapped[str] = mapped_column(Enum(*CONTEXTS, name="life_context", create_type=False), primary_key=True)
    source: Mapped[str] = mapped_column(Enum(*SOURCES, name="source_type", create_type=False), default="manual")
    status: Mapped[str] = mapped_column(Enum(*LINK_STATUSES, name="link_status", create_type=False), default="confirmed")
    confidence: Mapped[int | None] = mapped_column(SmallInteger)


class Goal(Base):
    __tablename__ = "goals"

    id: Mapped[uuid.UUID] = _uid_pk()
    user_id: Mapped[uuid.UUID] = _owner()
    name: Mapped[str] = mapped_column(Text)
    why: Mapped[str | None] = mapped_column(Text)
    priority: Mapped[str] = mapped_column(Enum(*PRIORITIES, name="priority_level", create_type=False), default="medium")
    deadline: Mapped[date | None] = mapped_column(Date)
    archived: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    milestones: Mapped[list["Milestone"]] = relationship(
        cascade="all, delete-orphan", lazy="selectin", order_by="Milestone.position"
    )


class Milestone(Base):
    __tablename__ = "milestones"

    id: Mapped[uuid.UUID] = _uid_pk()
    goal_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("goals.id", ondelete="CASCADE"))
    title: Mapped[str] = mapped_column(Text)
    done: Mapped[bool] = mapped_column(Boolean, default=False)
    position: Mapped[int] = mapped_column(Integer, default=0)


class Habit(Base):
    __tablename__ = "habits"

    id: Mapped[uuid.UUID] = _uid_pk()
    user_id: Mapped[uuid.UUID] = _owner()
    name: Mapped[str] = mapped_column(Text)
    target_per_week: Mapped[int] = mapped_column(SmallInteger, default=4)
    goal_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("goals.id", ondelete="SET NULL"))
    archived: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class HabitLog(Base):
    __tablename__ = "habit_logs"

    habit_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("habits.id", ondelete="CASCADE"), primary_key=True)
    log_date: Mapped[date] = mapped_column(Date, primary_key=True)
