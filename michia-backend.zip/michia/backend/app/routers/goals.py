import uuid

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, get_owned
from ..models import Goal, Milestone, User
from ..schemas import GoalIn, GoalOut, GoalUpdate, MilestoneIn, MilestoneOut, MilestoneUpdate

router = APIRouter(prefix="/goals", tags=["goals"])


def goal_out(g: Goal) -> GoalOut:
    done = sum(m.done for m in g.milestones)
    progress = round(done / len(g.milestones) * 100) if g.milestones else 0
    return GoalOut(id=g.id, name=g.name, why=g.why, priority=g.priority, deadline=g.deadline,
                   archived=g.archived, created_at=g.created_at, progress=progress,
                   milestones=[MilestoneOut.model_validate(m) for m in g.milestones])


def _milestone(db: Session, goal: Goal, mid: uuid.UUID) -> Milestone:
    m = next((m for m in goal.milestones if m.id == mid), None)
    if not m:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Milestone tidak ditemukan")
    return m


@router.post("", response_model=GoalOut, status_code=status.HTTP_201_CREATED)
def create(body: GoalIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    titles = [t.strip() for t in body.milestones if t.strip()]
    g = Goal(user_id=user.id, name=body.name.strip(), why=body.why, priority=body.priority, deadline=body.deadline,
             milestones=[Milestone(title=t, position=i) for i, t in enumerate(titles)])
    db.add(g)
    db.commit()
    db.refresh(g)
    return goal_out(g)


@router.get("", response_model=list[GoalOut])
def list_goals(include_archived: bool = False, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = select(Goal).where(Goal.user_id == user.id).order_by(Goal.created_at)
    if not include_archived:
        q = q.where(Goal.archived.is_(False))
    return [goal_out(g) for g in db.scalars(q).all()]


@router.get("/{goal_id}", response_model=GoalOut)
def get_goal(goal_id: uuid.UUID, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return goal_out(get_owned(db, Goal, goal_id, user, "Goal"))


@router.patch("/{goal_id}", response_model=GoalOut)
def update(goal_id: uuid.UUID, body: GoalUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    g = get_owned(db, Goal, goal_id, user, "Goal")
    for k, v in body.model_dump(exclude_unset=True).items():
        if k in ("name", "priority", "archived") and v is None:
            continue  # kolom ini tidak boleh dikosongkan
        setattr(g, k, v)
    db.commit()
    db.refresh(g)
    return goal_out(g)


@router.delete("/{goal_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete(goal_id: uuid.UUID, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(get_owned(db, Goal, goal_id, user, "Goal"))
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/{goal_id}/milestones", response_model=GoalOut, status_code=status.HTTP_201_CREATED)
def add_milestone(goal_id: uuid.UUID, body: MilestoneIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    g = get_owned(db, Goal, goal_id, user, "Goal")
    g.milestones.append(Milestone(title=body.title.strip(), position=len(g.milestones)))
    db.commit()
    db.refresh(g)
    return goal_out(g)


@router.patch("/{goal_id}/milestones/{milestone_id}", response_model=GoalOut)
def update_milestone(goal_id: uuid.UUID, milestone_id: uuid.UUID, body: MilestoneUpdate,
                     user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    g = get_owned(db, Goal, goal_id, user, "Goal")
    m = _milestone(db, g, milestone_id)
    if body.title is not None:
        m.title = body.title.strip()
    if body.done is not None:
        m.done = body.done
    db.commit()
    db.refresh(g)
    return goal_out(g)


@router.delete("/{goal_id}/milestones/{milestone_id}", response_model=GoalOut)
def delete_milestone(goal_id: uuid.UUID, milestone_id: uuid.UUID, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    g = get_owned(db, Goal, goal_id, user, "Goal")
    g.milestones.remove(_milestone(db, g, milestone_id))
    db.commit()
    db.refresh(g)
    return goal_out(g)
