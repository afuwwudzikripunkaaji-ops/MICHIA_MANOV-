import uuid
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, get_owned
from ..models import Goal, Habit, HabitLog, User
from ..schemas import HabitIn, HabitOut, HabitUpdate

router = APIRouter(prefix="/habits", tags=["habits"])


def _check_goal(db: Session, goal_id, user: User):
    if goal_id is not None:
        get_owned(db, Goal, goal_id, user, "Goal")  # goal harus milik user yang sama


def _outs(db: Session, habits: list[Habit], on: date) -> list[HabitOut]:
    ids = [h.id for h in habits]
    monday = on - timedelta(days=on.weekday())  # minggu dimulai hari Senin
    week = dict(db.execute(
        select(HabitLog.habit_id, func.count()).where(
            HabitLog.habit_id.in_(ids), HabitLog.log_date >= monday, HabitLog.log_date <= monday + timedelta(days=6)
        ).group_by(HabitLog.habit_id)).all()) if ids else {}
    today = set(db.scalars(select(HabitLog.habit_id).where(HabitLog.habit_id.in_(ids), HabitLog.log_date == on)).all()) if ids else set()
    return [HabitOut(id=h.id, name=h.name, target_per_week=h.target_per_week, goal_id=h.goal_id,
                     archived=h.archived, done_today=h.id in today, done_this_week=week.get(h.id, 0)) for h in habits]


@router.post("", response_model=HabitOut, status_code=status.HTTP_201_CREATED)
def create(body: HabitIn, on: date | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _check_goal(db, body.goal_id, user)
    h = Habit(user_id=user.id, name=body.name.strip(), target_per_week=body.target_per_week, goal_id=body.goal_id)
    db.add(h)
    db.commit()
    db.refresh(h)
    return _outs(db, [h], on or date.today())[0]


@router.get("", response_model=list[HabitOut])
def list_habits(on: date | None = None, include_archived: bool = False,
                user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """`on` = tanggal lokal user (YYYY-MM-DD) agar 'hari ini' sesuai zona waktunya."""
    q = select(Habit).where(Habit.user_id == user.id).order_by(Habit.created_at)
    if not include_archived:
        q = q.where(Habit.archived.is_(False))
    return _outs(db, list(db.scalars(q).all()), on or date.today())


@router.patch("/{habit_id}", response_model=HabitOut)
def update(habit_id: uuid.UUID, body: HabitUpdate, on: date | None = None,
           user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    h = get_owned(db, Habit, habit_id, user, "Habit")
    data = body.model_dump(exclude_unset=True)
    if data.get("goal_id"):
        _check_goal(db, data["goal_id"], user)
    for k, v in data.items():
        if k in ("name", "target_per_week", "archived") and v is None:
            continue
        setattr(h, k, v)
    db.commit()
    db.refresh(h)
    return _outs(db, [h], on or date.today())[0]


@router.delete("/{habit_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete(habit_id: uuid.UUID, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(get_owned(db, Habit, habit_id, user, "Habit"))
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put("/{habit_id}/logs/{day}", status_code=status.HTTP_204_NO_CONTENT)
def check(habit_id: uuid.UUID, day: date, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Centang habit pada tanggal tertentu (idempoten)."""
    get_owned(db, Habit, habit_id, user, "Habit")
    if not db.get(HabitLog, (habit_id, day)):
        db.add(HabitLog(habit_id=habit_id, log_date=day))
        db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.delete("/{habit_id}/logs/{day}", status_code=status.HTTP_204_NO_CONTENT)
def uncheck(habit_id: uuid.UUID, day: date, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    get_owned(db, Habit, habit_id, user, "Habit")
    log = db.get(HabitLog, (habit_id, day))
    if log:
        db.delete(log)
        db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
