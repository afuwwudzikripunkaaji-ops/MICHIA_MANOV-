from fastapi import APIRouter, Depends, HTTPException, Response, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import AISettings, User
from ..schemas import MeUpdate, RegisterIn, TokenOut, UserOut
from ..security import DUMMY_HASH, create_access_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


def to_out(u: User) -> UserOut:
    mode = u.ai_settings.mode if u.ai_settings else "auto"
    return UserOut(id=u.id, email=u.email, display_name=u.display_name, theme=u.theme,
                   onboarded=u.onboarded, ai_mode=mode)


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(body: RegisterIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Email sudah terdaftar")
    user = User(email=email, password_hash=hash_password(body.password), display_name=body.display_name)
    user.ai_settings = AISettings(mode="auto")
    db.add(user)
    db.commit()
    db.refresh(user)
    return to_out(user)


@router.post("/login", response_model=TokenOut)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    # Form OAuth2 memakai field "username"; isi dengan email.
    user = db.scalar(select(User).where(User.email == form.username.lower()))
    ok = verify_password(form.password, user.password_hash if user else DUMMY_HASH)
    if not user or not ok:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Email atau password salah")
    return TokenOut(access_token=create_access_token(user.id))


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return to_out(user)


@router.patch("/me", response_model=UserOut)
def update_me(body: MeUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = body.model_dump(exclude_unset=True)
    if "ai_mode" in data:
        if not user.ai_settings:
            user.ai_settings = AISettings()
        user.ai_settings.mode = data.pop("ai_mode")
    for k, v in data.items():
        setattr(user, k, v)
    db.commit()
    db.refresh(user)
    return to_out(user)


@router.delete("/me", status_code=status.HTTP_204_NO_CONTENT)
def delete_me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Hapus akun beserta seluruh datanya (prinsip: user owns the journal)."""
    db.delete(user)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
