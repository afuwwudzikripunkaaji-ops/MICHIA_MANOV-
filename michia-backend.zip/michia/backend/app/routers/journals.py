import uuid

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, get_owned
from ..models import Journal, JournalContext, User
from ..schemas import JournalIn, JournalOut, JournalUpdate

router = APIRouter(prefix="/journals", tags=["journals"])


def _sync_contexts(j: Journal, wanted: list[str]):
    """Samakan konteks jurnal dengan daftar baru tanpa menghapus-dan-menambah baris yang sama."""
    want = set(wanted)
    j.contexts = [c for c in j.contexts if c.context in want]
    have = {c.context for c in j.contexts}
    j.contexts.extend(JournalContext(context=c, source="manual", status="confirmed") for c in want - have)


@router.post("", response_model=JournalOut, status_code=status.HTTP_201_CREATED)
def create(body: JournalIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    j = Journal(user_id=user.id, body=body.body.strip())
    _sync_contexts(j, body.contexts)
    db.add(j)
    db.commit()
    db.refresh(j)
    return j


@router.get("", response_model=list[JournalOut])
def list_journals(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                  user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = select(Journal).where(Journal.user_id == user.id).order_by(Journal.created_at.desc()).limit(limit).offset(offset)
    return db.scalars(q).all()


@router.get("/{journal_id}", response_model=JournalOut)
def get_journal(journal_id: uuid.UUID, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return get_owned(db, Journal, journal_id, user, "Jurnal")


@router.patch("/{journal_id}", response_model=JournalOut)
def update(journal_id: uuid.UUID, body: JournalUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    j = get_owned(db, Journal, journal_id, user, "Jurnal")
    if body.body is not None:
        j.body = body.body.strip()
    if body.contexts is not None:
        _sync_contexts(j, body.contexts)
    db.commit()
    db.refresh(j)
    return j


@router.delete("/{journal_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete(journal_id: uuid.UUID, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(get_owned(db, Journal, journal_id, user, "Jurnal"))
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
