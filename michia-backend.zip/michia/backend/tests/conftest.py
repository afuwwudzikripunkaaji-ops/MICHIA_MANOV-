import os

os.environ.setdefault("SECRET_KEY", "test-secret-key-test-secret-key-1234")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app


@pytest.fixture()
def client():
    # Tes memakai SQLite in-memory supaya tidak butuh PostgreSQL.
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)

    @event.listens_for(engine, "connect")
    def _fk(conn, _):
        conn.execute("PRAGMA foreign_keys=ON")  # aktifkan FK di SQLite agar CASCADE ikut teruji

    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False)

    def override():
        with Session() as db:
            yield db

    app.dependency_overrides[get_db] = override
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture()
def auth(client):
    """Buat user dan kembalikan fungsi pembuat header; bisa dipanggil dengan email lain."""
    def make(email="abil@example.com"):
        client.post("/auth/register", json={"email": email, "password": "rahasia123"})
        t = client.post("/auth/login", data={"username": email, "password": "rahasia123"}).json()["access_token"]
        return {"Authorization": f"Bearer {t}"}
    return make
