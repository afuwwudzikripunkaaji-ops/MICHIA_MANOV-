def test_journals_crud_and_isolation(client, auth):
    a, b = auth(), auth("lain@example.com")
    r = client.post("/journals", json={"body": "Praktikum ESP32 hari ini", "contexts": ["study", "mood", "study"]}, headers=a)
    assert r.status_code == 201
    j = r.json()
    assert sorted(c["context"] for c in j["contexts"]) == ["mood", "study"]
    r = client.patch(f"/journals/{j['id']}", json={"body": "Diedit", "contexts": ["sleep_health", "mood"]}, headers=a)
    assert sorted(c["context"] for c in r.json()["contexts"]) == ["mood", "sleep_health"] and r.json()["body"] == "Diedit"
    assert len(client.get("/journals", headers=a).json()) == 1
    assert client.get("/journals", headers=b).json() == []
    assert client.get(f"/journals/{j['id']}", headers=b).status_code == 404
    assert client.delete(f"/journals/{j['id']}", headers=b).status_code == 404
    assert client.post("/journals", json={"body": "x", "contexts": ["bogus"]}, headers=a).status_code == 422
    assert client.delete(f"/journals/{j['id']}", headers=a).status_code == 204
    assert client.get("/journals", headers=a).json() == []


def test_goals_milestones_progress(client, auth):
    h = auth()
    g = client.post("/goals", json={"name": "Embedded", "why": "bikin alat", "priority": "high",
                                     "milestones": ["I2C", "Relay", " "]}, headers=h).json()
    assert g["progress"] == 0 and [m["title"] for m in g["milestones"]] == ["I2C", "Relay"]
    m0 = g["milestones"][0]["id"]
    g = client.patch(f"/goals/{g['id']}/milestones/{m0}", json={"done": True}, headers=h).json()
    assert g["progress"] == 50
    g = client.post(f"/goals/{g['id']}/milestones", json={"title": "LCD"}, headers=h).json()
    assert g["progress"] == 33 and len(g["milestones"]) == 3
    g = client.patch(f"/goals/{g['id']}", json={"priority": "low", "archived": True}, headers=h).json()
    assert g["priority"] == "low"
    assert client.get("/goals", headers=h).json() == []
    assert len(client.get("/goals?include_archived=true", headers=h).json()) == 1
    assert client.delete(f"/goals/{g['id']}", headers=h).status_code == 204


def test_habits_logs_and_goal_ownership(client, auth):
    a, b = auth(), auth("lain@example.com")
    goal = client.post("/goals", json={"name": "G"}, headers=a).json()
    assert client.post("/habits", json={"name": "Coding", "goal_id": goal["id"]}, headers=b).status_code == 404
    hb = client.post("/habits", json={"name": "Coding", "target_per_week": 4, "goal_id": goal["id"]}, headers=a).json()
    day = "2026-10-07"  # Rabu; minggunya Senin 5 - Minggu 11 Okt
    assert client.put(f"/habits/{hb['id']}/logs/{day}", headers=a).status_code == 204
    assert client.put(f"/habits/{hb['id']}/logs/{day}", headers=a).status_code == 204  # idempoten
    client.put(f"/habits/{hb['id']}/logs/2026-10-05", headers=a)
    client.put(f"/habits/{hb['id']}/logs/2026-10-12", headers=a)  # minggu berikutnya
    h = client.get(f"/habits?on={day}", headers=a).json()[0]
    assert h["done_today"] is True and h["done_this_week"] == 2
    assert client.put(f"/habits/{hb['id']}/logs/{day}", headers=b).status_code == 404
    client.delete(f"/habits/{hb['id']}/logs/{day}", headers=a)
    assert client.get(f"/habits?on={day}", headers=a).json()[0]["done_today"] is False
    # hapus goal -> habit tetap ada, goal_id jadi null
    client.delete(f"/goals/{goal['id']}", headers=a)
    assert client.get(f"/habits?on={day}", headers=a).json()[0]["goal_id"] is None


def test_delete_account_removes_data(client, auth):
    h = auth()
    client.post("/journals", json={"body": "rahasia"}, headers=h)
    client.post("/goals", json={"name": "G", "milestones": ["a"]}, headers=h)
    client.post("/habits", json={"name": "H"}, headers=h)
    assert client.delete("/auth/me", headers=h).status_code == 204
    h2 = auth()  # daftar ulang dengan email sama => akun baru yang bersih
    assert client.get("/journals", headers=h2).json() == [] and client.get("/goals", headers=h2).json() == []
