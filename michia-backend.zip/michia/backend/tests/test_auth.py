def register(c, email="abil@example.com", pw="rahasia123"):
    return c.post("/auth/register", json={"email": email, "password": pw, "display_name": "Abil"})


def token(c, email="abil@example.com", pw="rahasia123"):
    r = c.post("/auth/login", data={"username": email, "password": pw})
    return r


def test_register_login_me(client):
    assert register(client).status_code == 201
    r = token(client)
    assert r.status_code == 200
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    me = client.get("/auth/me", headers=h).json()
    assert me["email"] == "abil@example.com" and me["ai_mode"] == "auto" and me["onboarded"] is False


def test_duplicate_email_and_wrong_password(client):
    register(client)
    assert register(client, email="ABIL@example.com").status_code == 409
    assert token(client, pw="salahsalah").status_code == 401
    assert token(client, email="nope@example.com").status_code == 401


def test_update_and_delete(client):
    register(client)
    h = {"Authorization": f"Bearer {token(client).json()['access_token']}"}
    r = client.patch("/auth/me", json={"theme": "ocean", "ai_mode": "off", "onboarded": True}, headers=h)
    assert r.json()["theme"] == "ocean" and r.json()["ai_mode"] == "off" and r.json()["onboarded"] is True
    assert client.patch("/auth/me", json={"theme": "neon"}, headers=h).status_code == 422
    assert client.delete("/auth/me", headers=h).status_code == 204
    assert client.get("/auth/me", headers=h).status_code == 401


def test_requires_token(client):
    assert client.get("/auth/me").status_code == 401
